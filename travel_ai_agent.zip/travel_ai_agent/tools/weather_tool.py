from datetime import datetime


# Static weather data per city and season
# Seasons: winter (Nov–Feb), summer (Mar–May), monsoon (Jun–Sep), post-monsoon (Oct)

_WEATHER: dict[str, dict[str, dict]] = {
    "Goa": {
        "winter":      {"condition": "Sunny & Pleasant", "temp_min": 20, "temp_max": 32, "humidity": "60%", "tip": "Best time to visit — clear skies and comfortable temperatures."},
        "summer":      {"condition": "Hot & Humid",      "temp_min": 26, "temp_max": 36, "humidity": "75%", "tip": "Crowds thin out; some beach shacks may close."},
        "monsoon":     {"condition": "Heavy Rains",      "temp_min": 24, "temp_max": 30, "humidity": "90%", "tip": "Dudhsagar Falls is spectacular but roads can flood. Pack a raincoat."},
        "post_monsoon":{"condition": "Partly Cloudy",    "temp_min": 23, "temp_max": 33, "humidity": "70%", "tip": "Greenery is lush; tourist season is just beginning."},
    },
    "Mumbai": {
        "winter":      {"condition": "Pleasant & Mild",  "temp_min": 17, "temp_max": 31, "humidity": "65%", "tip": "Ideal sightseeing weather."},
        "summer":      {"condition": "Hot & Muggy",      "temp_min": 25, "temp_max": 38, "humidity": "80%", "tip": "Stay hydrated; evenings are more bearable on Marine Drive."},
        "monsoon":     {"condition": "Heavy Monsoon",    "temp_min": 23, "temp_max": 30, "humidity": "90%", "tip": "Expect waterlogging; local trains can be disrupted."},
        "post_monsoon":{"condition": "Warm & Cloudy",    "temp_min": 24, "temp_max": 34, "humidity": "72%", "tip": "City starts to cool; Ganesh Chaturthi season in September."},
    },
    "Delhi": {
        "winter":      {"condition": "Cold & Foggy",     "temp_min": 4,  "temp_max": 20, "humidity": "70%", "tip": "Carry woolens; morning fog can delay flights."},
        "summer":      {"condition": "Very Hot & Dry",   "temp_min": 28, "temp_max": 46, "humidity": "30%", "tip": "Travel early mornings only; heat waves are common in May."},
        "monsoon":     {"condition": "Warm with Rain",   "temp_min": 26, "temp_max": 36, "humidity": "80%", "tip": "Temperature drops somewhat; waterlogging in low-lying areas."},
        "post_monsoon":{"condition": "Pleasant & Clear", "temp_min": 18, "temp_max": 33, "humidity": "55%", "tip": "Excellent weather for sightseeing."},
    },
    "Jaipur": {
        "winter":      {"condition": "Cool & Sunny",     "temp_min": 8,  "temp_max": 22, "humidity": "50%", "tip": "Best time to visit. Cold nights — carry a jacket."},
        "summer":      {"condition": "Very Hot & Dry",   "temp_min": 27, "temp_max": 44, "humidity": "25%", "tip": "Avoid midday; indoor palaces and museums are a good retreat."},
        "monsoon":     {"condition": "Warm with Showers","temp_min": 24, "temp_max": 35, "humidity": "75%", "tip": "Occasional heavy showers; forts look dramatic in the rain."},
        "post_monsoon":{"condition": "Pleasant",         "temp_min": 20, "temp_max": 33, "humidity": "45%", "tip": "Great time to visit before the winter rush."},
    },
    "Chennai": {
        "winter":      {"condition": "Warm & Humid",     "temp_min": 20, "temp_max": 29, "humidity": "75%", "tip": "North-east monsoon in Nov–Dec; short heavy showers possible."},
        "summer":      {"condition": "Hot & Humid",      "temp_min": 28, "temp_max": 40, "humidity": "70%", "tip": "Very hot; stick to early mornings and air-conditioned interiors."},
        "monsoon":     {"condition": "Partly Rainy",     "temp_min": 26, "temp_max": 35, "humidity": "80%", "tip": "South-west monsoon is weaker here; less rain than the west coast."},
        "post_monsoon":{"condition": "Warm & Sunny",     "temp_min": 24, "temp_max": 33, "humidity": "70%", "tip": "Comfortable for beach visits in October."},
    },
    "Hyderabad": {
        "winter":      {"condition": "Cool & Pleasant",  "temp_min": 13, "temp_max": 28, "humidity": "55%", "tip": "Ideal weather; December can be chilly at night."},
        "summer":      {"condition": "Hot & Dry",        "temp_min": 24, "temp_max": 42, "humidity": "30%", "tip": "Very hot in April–May; stay hydrated."},
        "monsoon":     {"condition": "Warm with Rain",   "temp_min": 22, "temp_max": 32, "humidity": "80%", "tip": "Moderate rains; Hussain Sagar lake fills up beautifully."},
        "post_monsoon":{"condition": "Pleasant",         "temp_min": 20, "temp_max": 30, "humidity": "55%", "tip": "Good time to explore the city."},
    },
    "Kolkata": {
        "winter":      {"condition": "Cool & Pleasant",  "temp_min": 12, "temp_max": 26, "humidity": "60%", "tip": "Best time to visit; Durga Puja in October is unmissable."},
        "summer":      {"condition": "Hot & Humid",      "temp_min": 27, "temp_max": 40, "humidity": "70%", "tip": "Very uncomfortable; avoid if possible."},
        "monsoon":     {"condition": "Heavy Rains",      "temp_min": 26, "temp_max": 33, "humidity": "90%", "tip": "Flooding possible in low-lying areas; carry rain gear."},
        "post_monsoon":{"condition": "Warm & Clearing",  "temp_min": 22, "temp_max": 32, "humidity": "70%", "tip": "Festival season begins; Durga Puja preparations are festive."},
    },
    "Bangalore": {
        "winter":      {"condition": "Pleasant & Cool",  "temp_min": 15, "temp_max": 27, "humidity": "60%", "tip": "Best weather in India during winter — mild and breezy."},
        "summer":      {"condition": "Warm & Breezy",    "temp_min": 20, "temp_max": 33, "humidity": "50%", "tip": "Pre-monsoon thunderstorms in April–May; comfortable overall."},
        "monsoon":     {"condition": "Moderate Rains",   "temp_min": 19, "temp_max": 27, "humidity": "80%", "tip": "Pleasant rains; city stays green. Traffic can slow during heavy showers."},
        "post_monsoon":{"condition": "Clear & Pleasant", "temp_min": 18, "temp_max": 28, "humidity": "60%", "tip": "Great weather; parks and gardens are lush."},
    },
}

_DEFAULT = {"condition": "Generally Moderate", "temp_min": 20, "temp_max": 35, "humidity": "65%", "tip": "Check local forecasts before travel."}


def _season(month: int) -> str:
    if month in (11, 12, 1, 2):
        return "winter"
    if month in (3, 4, 5):
        return "summer"
    if month in (6, 7, 8, 9):
        return "monsoon"
    return "post_monsoon"


class WeatherTool:

    def get_weather(self, city: str, month: int | None = None) -> dict:
        """
        Return weather info for *city* in *month* (1–12).
        Defaults to the current calendar month.
        """
        if month is None:
            month = datetime.now().month

        season   = _season(month)
        city_map = _WEATHER.get(city, {})
        data     = city_map.get(season, _DEFAULT).copy()
        data.update({
            "city":   city,
            "season": season.replace("_", "-"),
            "month":  datetime(2000, month, 1).strftime("%B"),
        })
        return data
