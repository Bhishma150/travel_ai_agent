"""
PlacesDiscoveryTool — powered by OpenTripMap (free tier)
Requires: OPENTRIPMAP_KEY in your .env file
Sign up free at: https://dev.opentripmap.org/product
"""

import os
import time
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY  = os.getenv("OPENTRIPMAP_KEY", "")
BASE_URL = "https://api.opentripmap.com/0.1/en/places"

PREFERENCE_KINDS = {
    "beach":      "beaches,water",
    "adventure":  "sport,outdoor_activities,natural",
    "luxury":     "5star_hotels,spas",
    "budget":     "hostels,budget_hotels",
    "family":     "amusements,zoos,water_parks,children_museums",
    "nightlife":  "bars,clubs,pubs",
    "historical": "historic,cultural,architecture,museums",
    "relaxation": "spas,parks,gardens,scenic_views",
    "nature":     "natural,parks,gardens,waterfalls,mountains",
    "food":       "restaurants,foods,marketplaces",
    "shopping":   "shops,marketplaces,malls",
    "religious":  "religion,hinduism,islam,christianity,buddhism,sikhism",
    "mixed":      "interesting_places,tourist_facilities",
}
DEFAULT_KINDS = "interesting_places,cultural,historic,natural,architecture"


def _get_coords(city: str) -> tuple | None:
    """Resolve city name to (lat, lon) via OpenTripMap geoname endpoint."""
    try:
        resp = requests.get(
            f"{BASE_URL}/geoname",
            params={"name": city, "country": "IN", "apikey": API_KEY},
            timeout=8,
        )
        data = resp.json()
        if "lat" in data and "lon" in data:
            return float(data["lat"]), float(data["lon"])
    except Exception as e:
        print(f"[PlacesTool] Geoname lookup failed for {city}: {e}")
    return None


def _get_place_detail(xid: str) -> dict:
    """Fetch full detail for one place by xid."""
    try:
        resp = requests.get(
            f"{BASE_URL}/xid/{xid}",
            params={"apikey": API_KEY},
            timeout=8,
        )
        return resp.json()
    except Exception:
        return {}


class PlacesDiscoveryTool:

    def search_places(self, city: str, preference: str = "") -> list:
        if not API_KEY:
            print("[PlacesTool] No OPENTRIPMAP_KEY — using local JSON fallback.")
            return self._local_fallback(city)

        coords = _get_coords(city)
        if not coords:
            return self._local_fallback(city)

        lat, lon = coords

        pref_lower = preference.lower() if preference else ""
        kinds = DEFAULT_KINDS
        for key, val in PREFERENCE_KINDS.items():
            if key in pref_lower:
                kinds = val
                break

        try:
            resp = requests.get(
                f"{BASE_URL}/radius",
                params={
                    "radius":  20000,
                    "lat":     lat,
                    "lon":     lon,
                    "kinds":   kinds,
                    "rate":    "3",
                    "format":  "json",
                    "limit":   20,
                    "apikey":  API_KEY,
                },
                timeout=10,
            )
            items = resp.json()
            if not isinstance(items, list):
                raise ValueError(f"Unexpected response: {items}")
        except Exception as e:
            print(f"[PlacesTool] radius search failed: {e} — using local fallback.")
            return self._local_fallback(city)

        results = []
        for item in items[:8]:
            xid  = item.get("xid", "")
            name = item.get("name", "").strip()
            if not name:
                continue

            detail    = _get_place_detail(xid)
            time.sleep(0.15)

            kinds_str = detail.get("kinds", item.get("kinds", ""))
            category  = kinds_str.split(",")[0].replace("_", " ").title() if kinds_str else "Attraction"

            results.append({
                "city":        city,
                "name":        name,
                "category":    category,
                "rating":      round(item.get("rate", 0) / 3 * 5, 1),
                "entry_fee":   0,
                "description": (
                    detail.get("wikipedia_extracts", {}).get("text", "")[:200]
                    or detail.get("info", {}).get("descr", "")[:200]
                    or f"A popular attraction in {city}."
                ),
            })

        return results if results else self._local_fallback(city)

    def top_places(self, places: list, n: int = 5) -> list:
        return sorted(places, key=lambda p: p.get("rating", 0), reverse=True)[:n]

    def _local_fallback(self, city: str) -> list:
        import json, os
        path = os.path.join(os.path.dirname(__file__), "..", "data", "places.json")
        try:
            with open(path) as f:
                data = json.load(f)
            return [p for p in data if p.get("city", "").lower() == city.lower()]
        except Exception:
            return []
