"""
HotelRecommendationTool — powered by OpenTripMap (free tier)
Fetches accommodations tagged as hotels/hostels near the city centre.
Requires: OPENTRIPMAP_KEY in your .env file
"""

import os
import time
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY  = os.getenv("OPENTRIPMAP_KEY", "")
BASE_URL = "https://api.opentripmap.com/0.1/en/places"

# OpenTripMap kinds that represent accommodations
HOTEL_KINDS = "accomodations,hotels,hostels,campsites"

# Rough budget-to-type mapping for filtering
PREF_TYPE_MAP = {
    "luxury":  ["5star", "luxury", "resort", "palace", "taj", "oberoi", "leela"],
    "budget":  ["hostel", "budget", "zostel", "inn", "guesthouse", "lodge"],
    "family":  ["resort", "suites", "hotel"],
}


def _get_coords(city: str):
    try:
        resp = requests.get(
            f"{BASE_URL}/geoname",
            params={"name": city, "country": "IN", "apikey": API_KEY},
            timeout=8,
        )
        data = resp.json()
        if "lat" in data and "lon" in data:
            return float(data["lat"]), float(data["lon"])
    except Exception as e:
        print(f"[HotelTool] Geoname failed for {city}: {e}")
    return None


class HotelRecommendationTool:

    def search_hotels(self, city: str, preference: str = "") -> list:
        if not API_KEY:
            print("[HotelTool] No OPENTRIPMAP_KEY — using local JSON fallback.")
            return self._local_fallback(city)

        coords = _get_coords(city)
        if not coords:
            return self._local_fallback(city)

        lat, lon = coords

        try:
            resp = requests.get(
                f"{BASE_URL}/radius",
                params={
                    "radius":  15000,
                    "lat":     lat,
                    "lon":     lon,
                    "kinds":   HOTEL_KINDS,
                    "format":  "json",
                    "limit":   15,
                    "apikey":  API_KEY,
                },
                timeout=10,
            )
            items = resp.json()
            if not isinstance(items, list):
                raise ValueError(f"Unexpected: {items}")
        except Exception as e:
            print(f"[HotelTool] Radius search failed: {e} — using local fallback.")
            return self._local_fallback(city)

        results = []
        pref_lower = preference.lower()
        for item in items[:10]:
            name = item.get("name", "").strip()
            if not name or len(name) < 3:
                continue

            xid    = item.get("xid", "")
            detail = {}
            if xid:
                try:
                    dr = requests.get(
                        f"{BASE_URL}/xid/{xid}",
                        params={"apikey": API_KEY},
                        timeout=8,
                    )
                    detail = dr.json()
                    time.sleep(0.15)
                except Exception:
                    pass

            address = detail.get("address", {})
            addr_str = ", ".join(filter(None, [
                address.get("road", ""),
                address.get("suburb", ""),
                address.get("city", city),
            ]))

            results.append({
                "city":        city,
                "name":        name,
                "address":     addr_str or city,
                "stars":       detail.get("stars", "N/A"),
                "price_per_night": "Check booking site",
                "rating":      round(item.get("rate", 2) / 3 * 5, 1),
                "type":        "Hotel",
                "amenities":   [],
            })

        # Sort by rating
        results.sort(key=lambda h: h.get("rating", 0), reverse=True)

        return results if results else self._local_fallback(city)

    def _local_fallback(self, city: str) -> list:
        import json, os
        path = os.path.join(os.path.dirname(__file__), "..", "data", "hotels.json")
        try:
            with open(path) as f:
                data = json.load(f)
            return [h for h in data if h.get("city", "").lower() == city.lower()]
        except Exception:
            return []
