class BudgetTool:

    def estimate_budget(

            self,

            flight_cost,

            hotel_price_per_night,

            days,

            daily_expense=1500

    ):

        hotel_total = (

            hotel_price_per_night

            *

            days

        )

        local_expense = (

            daily_expense

            *

            days

        )

        total = (

            flight_cost

            +

            hotel_total

            +

            local_expense

        )

        return {

            "flight_cost":

                flight_cost,

            "hotel_cost":

                hotel_total,

            "local_expense":

                local_expense,

            "total_budget":

                total

        }


if __name__ == "__main__":

    tool = BudgetTool()

    flight = int(

        input(

            "Flight cost: "

        )

    )

    hotel = int(

        input(

            "Hotel per night: "

        )

    )

    days = int(

        input(

            "Days: "

        )

    )

    result = tool.estimate_budget(

        flight,

        hotel,

        days

    )

    print(

        "\nBudget Summary:\n"

    )

    print(result)