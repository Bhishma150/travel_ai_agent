"""
FlightSearchTool — uses local expanded JSON (no paid API needed).
The JSON covers 50+ Indian city-pair routes.
To extend: add more route objects to data/flights.json
"""

import json
import os

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "flights.json")


class FlightSearchTool:

    def __init__(self):
        try:
            with open(DATA_PATH) as f:
                self._data: list = json.load(f)
        except Exception as e:
            print(f"[FlightTool] Warning: could not load flights.json — {e}")
            self._data = []

    def search_flights(self, origin: str, destination: str) -> list:
        ol = origin.lower()
        dl = destination.lower()
        results = [
            f for f in self._data
            if f.get("from", "").lower() == ol
            and f.get("to",   "").lower() == dl
        ]
        results.sort(key=lambda f: f.get("price", 0))
        return results
